var loadedobjects=""
var rootdomain="http://"+window.location.hostname

function ajaxpage(url, containerid) {
	var page_request = false;
	if (window.XMLHttpRequest) // if Mozilla, Safari etc
		{
			page_request = new XMLHttpRequest()
		//	alert(window.XMLHttpRequest);
		}
	else if (window.ActiveXObject) { // if IE
		try 
			{
				page_request = new ActiveXObject("Msxml2.XMLHTTP")
			} 
		catch (e)
			{
				try
					{
						page_request = new ActiveXObject("Microsoft.XMLHTTP")
					}
				catch (e){}
			}
		}
	else
		return false
		page_request.onreadystatechange=function()
		{
			loadpage(page_request, containerid)
		}
		page_request.open('GET', url, true)
		page_request.send(null)
}

function loadpage(page_request, containerid)
	{	
		if (page_request.readyState == 4 && (page_request.status==200 || window.location.href.indexOf("http")==-1))
		window.parent.document.getElementById(containerid).innerHTML=page_request.responseText;

	}
	
function loadobjs() {
	if (!document.getElementById)
		return
	
	for (i=0; i<arguments.length; i++)
		{
			var file=arguments[i]
			var fileref=""
			if (loadedobjects.indexOf(file)==-1) //Check to see if this object has not already been added to page before proceeding
				{
					if (file.indexOf(".js")!=-1) //If object is a js file
						{ 
							fileref=document.createElement('script')
							fileref.setAttribute("type","text/javascript");
							fileref.setAttribute("src", file);
						}
					else if (file.indexOf(".css")!=-1) //If object is a css file
						{ 
							fileref=document.createElement("link")
							fileref.setAttribute("rel", "stylesheet");
							fileref.setAttribute("type", "text/css");
							fileref.setAttribute("href", file);
						}
				}
			if (fileref!="")
				{
					document.getElementsByTagName("head").item(0).appendChild(fileref)
					loadedobjects+=file+" " //Remember this object as being already added to page
				}
		}
}

function showPage()
{
		loading.style.display='none';
		MainPage.style.display='INLINE';
}

function pageLoad()
	{	
		ajaxpage('home/KNhome_head.htm','head');
		ajaxpage('home/KNhome_l.htm','KNsidebar');
		ajaxpage('home/KNkonect_b.htm','KNBodybar');
		ajaxpage('home/KNhome_r.htm','KNrightbar');
	}

function alertContents() {
      if (http_request.readyState == 4) 
		{
	         if (http_request.status == 200) 
			{
            	result = http_request.responseText;		
				var elements = result.split('<|>');
				  	if(elements[0]=='0')
						{ 										
							document.getElementById('title1').innerHTML=elements[1];
							document.getElementById('name').innerHTML = elements[2];
							document.getElementById('Textcontainer').style.display = 'none';
							document.getElementById('mailmessage').style.display = 'inline';	
						}
          	} 
		  	else
			 	{
            		alert('There was a problem with the request.');
         		}
      	}
}


/* **** Added By venkat On 01/01/2016 For calling a page through AJAX-----*/
   var http_request = false;
   function makeRequest(url, parameters) {
      http_request = false;
      if (window.XMLHttpRequest) { // Mozilla, Safari,...
         http_request = new XMLHttpRequest();
         if (http_request.overrideMimeType) {
            http_request.overrideMimeType('text/html');
         }
      } else if (window.ActiveXObject) { // IE
         try {
            http_request = new ActiveXObject("Msxml2.XMLHTTP");
         } catch (e) {
            try {
               http_request = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (e) {}
         }
      }
      if (!http_request) {
         alert('Cannot create XMLHTTP instance');
         return false;
      }
      http_request.onreadystatechange = alertContents;
      http_request.open('GET', url + parameters, true);
      http_request.send(null);
   }


	/* **** Added By venkat On 01/01/2016 Getting all Forms field values for AJAX-----*/
	function get(obj,pAction) {	 
      var getstr = "?";
        for (var i=0; i<obj.length; i++) {
		    if (obj[i].tagName == "INPUT") {
	            if (obj[i].type == "text") {
            	 getstr += obj[i].name + "=" + obj[i].value + "&";
            	}

	            if (obj[i].type == "hidden") {
            	 getstr += obj[i].name + "=" + obj[i].value + "&";
            	}
				if (obj[i].type == "checkbox")  {
               		if (obj[i].checked) 
					{
                	  getstr += obj[i].name + "=" + obj[i].value + "&";
               		}
					else 
					{
                  getstr += obj[i].name + "=&";
               		}
            	}
                if (obj[i].type == "radio") {
					if (obj[i].checked)
					{
					getstr += obj[i].name + "=" + obj[i].value + "&";
					}
				}
			}   
			if (obj[i].tagName == "SELECT") 
			{
        	    var sel = obj[i];
            	getstr += sel.name + "=" + sel.options[sel.selectedIndex].value + "&";
         	}
			if (obj[i].tagName == "TEXTAREA") 
			{
			    var tarea = obj[i];
            	getstr += tarea.name + "=" + tarea.value + "&";
			}
		}
        getstr += "id=" + Math.random();
    makeRequest(pAction, getstr);
   }


   function CheckBlank()	
   {  
      if ((document.contact.con_name.value == '')|(document.contact.con_email.value == '')|(document.contact.con_message.value == ''))
         {
	    alert("Please Fill all Mandatory Fields*");
	    return false;
	 }
      else
	 { 
	    if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(contact.con_email.value))
		{
		} 
	    else
		{
			alert("Invalid E-mail Address! Please re-enter.");
			return (false);
		}
	}

	get(document.contact,'contactus.asp');
	return true;
   }


var divfield ;
var subdiv;
var link;
function showContent(divfield,subdiv,link) {		 
	divfield = divfield;
	subdiv = subdiv;
	link = link;
	//alert(divfield);
	//alert(subdiv);
	//alert(link);
	var showHide = window.parent.document.getElementsByTagName('div'); 
	for(var i=0; i < showHide.length ; i++)
	{			  
		if(showHide[i].id == divfield)
		{ 						
			if (showHide[i].className == 'IgnoreLink') 
			{	
				showHide[i].className = 'Highlightlink';													
			}  
			if (showHide[i].className == 'sublink') 
			{	
				showHide[i].style.display='inline';														
			} 
		}
		else if(showHide[i].id != divfield)
		{  	  
			if (showHide[i].className == 'Highlightlink') 
			{	
				 showHide[i].className = 'IgnoreLink';
			}
			if (showHide[i].className == 'sublink') 
			{	
				showHide[i].style.display='none';	
			}			
			if(showHide[i].id == subdiv)
			{
				if (showHide[i].className == 'SubIgnoreLink') 
				{	
					showHide[i].className = 'SubHighlightlink';													
				}
			}
			else if(showHide[i].id != subdiv)
			{  	 
				if (showHide[i].className == 'SubHighlightlink') 
				{	
					showHide[i].className = 'SubIgnoreLink';													
				}  
			}
		}
	}
	ajaxpage(link, 'KNBodybar');  
}


function callFromProdMenu()
{
	if(document.form1.divfield.value !='')
	{
		showContent(document.form1.divfield.value,document.form1.subdiv.value,document.form1.link.value);
		document.form1.divfield.value='';document.form1.subdiv.value='';document.form1.link.value='';
	}
}


var statusmessagesg=""
function statusMsg()
{
	window.status=statusmessagesg 
	return true
}
